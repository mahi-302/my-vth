import json
import random
import string
import random
import string
import re
import boto3
import base64
import time
AMI ='ami-0fb653ca2d3203ac1'
INSTANCE_TYPE = 't2.micro'
REGION = 'us-east-2' 
#user_Data = 
#user_Data_bytes = user_Data.encode("ascii")
#base64_bytes = base64.b64encode(user_Data_bytes)
#base64_string = base64_bytes.decode("ascii") 

lb = boto3.client('elbv2', region_name=REGION)
asg = boto3.client('autoscaling', region_name=REGION) 
ec2 = boto3.client('ec2', region_name=REGION)
rds = boto3.client('rds', region_name=REGION)
def lambda_handler(event, context):
     
     key_pair = ec2.create_key_pair(
          KeyName= 'keyforproj',
          KeyType='rsa')
     print ("key pair created.")
     
     security_group = ec2.create_security_group(
          Description= 'allow all trafics',
          GroupName= 'sg',
          VpcId= 'vpc-0a7387e5c61ec7456')
     print ("security group created.")
     inbound_rule = ec2.authorize_security_group_ingress(
          GroupId= security_group['GroupId'],
          CidrIp='0.0.0.0/0',
          IpProtocol='all', 
          FromPort=1, 
          ToPort=255)
     print ("inbound_rule added.")    
     
     db_instance = rds.create_db_instance(
          DBName= 'covidtmsdb',
          DBInstanceIdentifier='myrds',
          AllocatedStorage=10,
          DBInstanceClass='db.t2.micro',
          Engine='mysql',
          MasterUsername='admin',
          MasterUserPassword='mahe8842',
          VpcSecurityGroupIds= [security_group['GroupId']],
          EngineVersion= '5.7',
          PubliclyAccessible=True)
     print ("RDS created.") 
     print ("wait for 3 minutes")
     time.sleep(300)
     db_instance_disc = rds.describe_db_instances( DBInstanceIdentifier='myrds')
     print ("db_instance discribed.")
     print (db_instance_disc['DBInstances'][0]['Endpoint']['Address'])
     end_point = db_instance_disc['DBInstances'][0]['Endpoint']['Address']
       
     load_balancer = lb.create_load_balancer(
          Name='my-load-balancer',
          Subnets=['subnet-08f3fd927977dc180','subnet-0c9f6c09d2f62dc2d'],
          Type='application',
          IpAddressType='ipv4')
     LoadBalancer_Arn = load_balancer['LoadBalancers'][0]['LoadBalancerArn']
     print (LoadBalancer_Arn)
     print ("load balancer created")
     
     target_group = lb.create_target_group(
          Name='my-target-group',
          Protocol='HTTP',
          Port=80,
          VpcId='vpc-0a7387e5c61ec7456',
          TargetType='instance')
     print ("Target group created.")
     
     listener = lb.create_listener(
          LoadBalancerArn= load_balancer['LoadBalancers'][0]['LoadBalancerArn'],
          Protocol='HTTP',
          Port=80,
          DefaultActions=[{'Type': 'forward', 'TargetGroupArn': target_group['TargetGroups'][0]['TargetGroupArn']}])
     print ("Listeners created")
     user_Data = f'''#!/bin/bash
sudo apt-get update -y
sudo apt-get upgrade -y
sudo wget https://www.apachefriends.org/xampp-files/8.1.2/xampp-linux-x64-8.1.2-0-installer.run
sudo chmod 755 xampp-linux-x64-8.1.2-0-installer.run
sudo ./xampp-linux-x64-8.1.2-0-installer.run
Y
Y
ENTER
Y
sudo apt install net-tools
sudo /opt/lampp/lampp start
sudo rm -rf /opt/lampp/htdocs/*
sudo chmod 777 /opt/lampp/htdocs
sudo git clone https://github.com/mahi-302/my-vth.git
sudo cp -r my-vth/covid\ test/covid-tms/* /opt/lampp/htdocs
sudo chmod 777 /opt/lampp/htdocs/includes/config.php
sudo sed -i.bak 's/localhost/{end_point}/g' /opt/lampp/htdocs/includes/config.php
sudo chmod 777 /opt/lampp/etc/extra/httpd-xampp.conf
sudo sed -i.bak 's/local/all granted/g' /opt/lampp/etc/extra/httpd-xampp.conf
sudo chmod 755 /opt/lampp/etc/extra/httpd-xampp.conf
sudo /opt/lampp/lampp restart
sudo chmod 777 /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["verbose"] = "Amazon RDS";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["host"] = "{end_point}";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["user"] = "admin";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["password"] = "mahe8842";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["port"] = "3306";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["auth_type"] = "config";' >> /opt/lampp/phpmyadmin/config.inc.php
sudo echo '$cfg["Servers"][$i]["AllowNoPassword"] = true;' >> /opt/lampp/phpmyadmin/config.inc.php
sudo chmod 400 /opt/lampp/phpmyadmin/config.inc.php
sudo /opt/lampp/lampp restart
sudo apt install mysql-client-core-8.0
sudo mysql -h {end_point} -u admin --password=mahe8842 covidtmsdb < /my-vth/covid\ test/SQL\ File/covidtmsdb.sql
'''
     user_Data_bytes = user_Data.encode("ascii")
     base64_bytes = base64.b64encode(user_Data_bytes)
     base64_string = base64_bytes.decode("ascii")
     launch_template = ec2.create_launch_template(
          LaunchTemplateName='myLtemp',
          LaunchTemplateData={
               'ImageId': AMI,
               'InstanceType': INSTANCE_TYPE,
               'KeyName': key_pair['KeyName'],
               'UserData': base64_string,
               'SecurityGroupIds': [security_group['GroupId']],
               'IamInstanceProfile': {'Name': 'role_all'}})
     print (launch_template)
     print ("Launch template created.")

     autoscaling_group = asg.create_auto_scaling_group(
          AutoScalingGroupName='my-asg',
          LaunchTemplate={'LaunchTemplateName': 'myLtemp'},
          MinSize=2,
          MaxSize=4,
          DesiredCapacity=2,
          AvailabilityZones=['us-east-2c','us-east-2a'],
          TargetGroupARNs=[target_group['TargetGroups'][0]['TargetGroupArn']])
     print (" asg Created with desired 2ec2")

     scaling_policy = asg.put_scaling_policy(
          AutoScalingGroupName= 'my-asg',
          PolicyName= 'target-tracking-scaling-policy',
          PolicyType='TargetTrackingScaling',
           TargetTrackingConfiguration={
               'PredefinedMetricSpecification': {
                    'PredefinedMetricType': 'ASGAverageCPUUtilization'
                    },
               'TargetValue': 10.0,
          },
     ) 
     print ("Scaling policy attached to ASG.")

     return (db_instance_disc['DBInstances'][0]['Endpoint']['Address'])